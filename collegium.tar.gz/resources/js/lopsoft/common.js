function tabNextField(next_id)
{
    $("#"+next_id).focus();
}

function getScreenWidth()
{
    return window.innerWidth;
}
