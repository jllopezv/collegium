@extends('lopsoft.layouts.page')

@section('content')

    @livewire('auth.update-profile')

@endsection

