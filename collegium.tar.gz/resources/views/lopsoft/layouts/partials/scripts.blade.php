<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.6.0/dist/alpine.js" defer></script>
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="{{ asset('js/lib/jquery.min.js')}}"></script>
<script src="{{ asset('js/lib/toastr.min.js')}}"></script>
<script src="{{ asset('js/lib/noty.min.js')}}"></script>
<script src="{{ asset('js/lopsoft.js') }}"></script>

