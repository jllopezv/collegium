@include('components.lopsoft.datatable.rowcolumn', ['slot'=> $item->name, 'classrow' => ''])
@include('components.lopsoft.datatable.rowcolumn', ['slot'=> $item->tag, 'classrow' => ''])
