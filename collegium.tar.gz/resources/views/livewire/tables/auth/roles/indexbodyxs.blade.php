<div class='mt-1 text-center'>
    <div><span class='text-xl text-gray-500'><b>{{ $item->level }}</b></span></div>
    <div><span class='text-gray-500'>{!! $item->getRoleTagAttribute() !!}</span></div>
</div>
