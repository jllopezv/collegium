<div class='mt-1 font-bold text-center'>
    {!! $item->level !!}
</div>
