<div class='mt-1 font-bold text-center'>
    {!! $item->grade !!}
</div>
<div class='mt-1 font-bold text-center'>
    {!! $item->level!=null?$item->level->level:null !!}
</div>
