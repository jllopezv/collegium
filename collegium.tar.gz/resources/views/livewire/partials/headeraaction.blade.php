<div>
    <div class='bg-gray-200 px-4 py-5 shadow'>
        <div class="text-xl md:text-2xl text-gray-800 ">{{ $headertext }}</div>
        <div class="text-xl md:text-xl text-gray-700 ">{{ $subheadertext??'' }}</div>
    </div>
</div>
