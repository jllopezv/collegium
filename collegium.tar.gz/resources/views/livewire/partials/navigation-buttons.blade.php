{{-- <x-lopsoft.link.coolgray x-ref='btnNavPrevious'  wire:click='navPrevious'   icon='fa fa-chevron-left'  />
<x-lopsoft.link.coolgray x-ref='btnNavNext'      wire:click='navNext'       icon='fa fa-chevron-right'  /> --}}
