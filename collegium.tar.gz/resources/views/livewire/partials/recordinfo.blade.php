@if($mode!='create')
    <div class='flex items-center justify-between px-4 pt-0 pb-1 m-0 text-right bg-gray-200'>
        <div class=''>
            @if( $mode=='show' && Auth::user()->level<=config('lopsoft.maxLevelAdmin') )
                <span class='px-2 text-sm font-bold text-green-200 bg-gray-500 rounded-md'>{{ $record->owner==null?'SYSTEM':$record->owner->username }}<span> <span class='text-xs text-gray-700'>{{ $record->created_aged!=''?"( $record->created_aged )":'' }}</span>
            @endif
        </div>
        <div>
            <span class='bg-blue-500 text-white py-0.5 px-1 text-xs rounded font-bold'>ID {{ $record->id }}</span>
            @if ($record->active)
                <span class='bg-green-400 text-white py-0.5 px-1 text-xs rounded font-bold'>ACTIVO</span>
            @else
                <span class='bg-red-500 text-white py-0.5 px-1 text-xs rounded font-bold'>NO ACTIVO</span>
            @endif
        </div>
    </div>
@endif
