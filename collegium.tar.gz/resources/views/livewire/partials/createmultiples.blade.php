<div class='text-right p-4 bg-white'>
    <x-lopsoft.control.checkbox model='multiple' label='CREAR MULTIPLES' positionlabel='before' classlabel='font-bold'/>
</div>
