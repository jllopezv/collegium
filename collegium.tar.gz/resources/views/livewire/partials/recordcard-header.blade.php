<div class='flex items-center justify-center mr-auto p-4 rounded-t-md bg-gray-700  text-white'>
    <div class='w-full py-2'>
        <div class='text-lg font-bold'>
            {{ $title }}
        </div>
        <div class='text-sm text-gray-400'>
            {{ $subtitle }}
        </div>
    </div>
</div>
