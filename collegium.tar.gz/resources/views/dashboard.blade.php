@extends('lopsoft.layouts.page')

@section('content')

@endsection
