<td {{ $attributes->merge([ 'class' => 'px-2 text-gray-600' ]) }}>
    {{ $slot }}
</td>
