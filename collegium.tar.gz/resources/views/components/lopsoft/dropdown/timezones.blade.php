{!! $record['name'] !!} ({{ $record['offset'] }})
