<?php

return [
    'username_mandatory' => 'Usuario Obligatorio',
    'password_mandatory' => 'Contraseña Obligatoria',
    'auth_error'         => 'Error de Autenticación',
    'user'               => 'Usuario',
    'password'           => 'Contraseña',
];
