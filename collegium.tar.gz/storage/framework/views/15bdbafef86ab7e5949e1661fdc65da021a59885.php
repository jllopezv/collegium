<?php $attributes = $attributes->exceptProps(['text' => '', 'labelwidth' => 'w-full']); ?>
<?php foreach (array_filter((['text' => '', 'labelwidth' => 'w-full']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<label <?php echo e($attributes->merge([
    'class' => 'block '.$labelwidth])); ?>>
    <?php echo $text ?? $slot; ?>

</label>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/control/label.blade.php ENDPATH**/ ?>