<?php $attributes = $attributes->exceptProps([
    'width'         => '',
    'columnname'    => 'columnname',
    'sortorder'         => '',
    'sortable'      => false,
    'justify'       => 'start'
]); ?>
<?php foreach (array_filter(([
    'width'         => '',
    'columnname'    => 'columnname',
    'sortorder'         => '',
    'sortable'      => false,
    'justify'       => 'start'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<th
    <?php if($sortable): ?>
        wire:click="sortBy('<?php echo e($columnname); ?>')"
    <?php endif; ?>
    <?php echo e($attributes->merge([
        'class' =>  ( $sortable || ( $sortorder==$columnname || $sortorder=='-'.$columnname ) )?"text-green-300 cursor-pointer":"text-white",
        'width' =>  $width,
    ])); ?>

    >
    <div class='flex items-center justify-<?php echo e($justify); ?> mx-2 py-2'>
        <div class=''>
            <?php echo e($slot); ?>

        </div>
        <div class='ml-1'>
            <?php if($sortable): ?>
                <?php if( $sortorder==$columnname || $sortorder=='-'.$columnname ): ?>
                    <?php if( \Illuminate\Support\Str::startsWith($sortorder,'-') ): ?>
                        <i class='fa fa-angle-down'></i>
                    <?php else: ?>
                        <i class='fa fa-angle-up'></i>
                    <?php endif; ?>
                <?php else: ?>
                    
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</th>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/header-th.blade.php ENDPATH**/ ?>