<div
    id='sidebar'
    x-cloak
    x-show.transition.opacity.duration.500ms='showsidebar'
    x-on:click.away='if (opensidebar==true)  checkWidth()'
    @resize.window='checkWidth()'
    :class="' bg-gray-800 text-white h-full text-xs transition-all duration-500  '+(opensidebar?' w-full sm:w-48 overflow-y-auto':'w-13')">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-open','data' => []]); ?>
<?php $component->withName('lopsoft.control.sidebar-open'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-link','data' => ['icon' => 'fa fa-home','link' => ''.e(route('dashboard')).'','text' => 'INICIO','help' => 'INICIO','class' => 'hover:text-green-300']]); ?>
<?php $component->withName('lopsoft.control.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'fa fa-home','link' => ''.e(route('dashboard')).'','text' => 'INICIO','help' => 'INICIO','class' => 'hover:text-green-300']); ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php if (\Illuminate\Support\Facades\Blade::check('hasAbilityOr', ["permission_groups.access", "permissions.access", "roles.access", "users.access"])): ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-menu','data' => ['icon' => 'fa fa-user','link' => 'linkeando','text' => 'ACCESOS','help' => 'ACCESOS','menuid' => 'menuacceso','classmenu' => 'hover:text-green-300']]); ?>
<?php $component->withName('lopsoft.control.sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'fa fa-user','link' => 'linkeando','text' => 'ACCESOS','help' => 'ACCESOS','menuid' => 'menuacceso','classmenu' => 'hover:text-green-300']); ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', "users.access")): ?>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('users.index')).'','text' => 'USUARIOS','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('users.index')).'','text' => 'USUARIOS','class' => 'hover:text-green-300','help' => '']); ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', "roles.access")): ?>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('roles.index')).'','text' => 'ROLES','class' => 'hover:text-green-300','help' => 'ROLES']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('roles.index')).'','text' => 'ROLES','class' => 'hover:text-green-300','help' => 'ROLES']); ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', "permissions.access")): ?>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('permissions.index')).'','text' => 'PERMISOS','class' => 'hover:text-green-300','help' => 'PERMISOS']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('permissions.index')).'','text' => 'PERMISOS','class' => 'hover:text-green-300','help' => 'PERMISOS']); ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', "permission_groups.access")): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('permission_groups.index')).'','text' => 'PERMISOS GRUP.','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('permission_groups.index')).'','text' => 'PERMISOS GRUP.','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('hasAbilityOr', ['students.access', 'school_levels.access', 'school_grades.access'])): ?>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-menu','data' => ['icon' => 'fa fa-user','link' => 'linkeando','text' => 'ACADÉMICO','help' => 'ACADÉMICO','menuid' => 'menuacademico','classmenu' => 'hover:text-green-300']]); ?>
<?php $component->withName('lopsoft.control.sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'fa fa-user','link' => 'linkeando','text' => 'ACADÉMICO','help' => 'ACADÉMICO','menuid' => 'menuacademico','classmenu' => 'hover:text-green-300']); ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['school_levels.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('school_levels.index')).'','text' => ''.e(transup('schoollevels')).'','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('school_levels.index')).'','text' => ''.e(transup('schoollevels')).'','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['school_grades.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('school_grades.index')).'','text' => ''.e(transup('schoolgrades')).'','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('school_grades.index')).'','text' => ''.e(transup('schoolgrades')).'','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['students.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('students.index')).'','text' => ''.e(transup('tables.students')).'','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('students.index')).'','text' => ''.e(transup('tables.students')).'','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('hasAbilityOr', ['colors.access','countries.access'])): ?>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-menu','data' => ['icon' => 'fa fa-user','link' => 'linkeando','text' => 'AUXILIARES','menuid' => 'menuauxiliares','classmenu' => 'hover:text-green-300']]); ?>
<?php $component->withName('lopsoft.control.sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'fa fa-user','link' => 'linkeando','text' => 'AUXILIARES','menuid' => 'menuauxiliares','classmenu' => 'hover:text-green-300']); ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['colors.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('colors.index')).'','text' => 'COLORES','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('colors.index')).'','text' => 'COLORES','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['countries.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('countries.index')).'','text' => ''.e(mb_strtoupper(__('lopsoft.countries'))).'','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('countries.index')).'','text' => ''.e(mb_strtoupper(__('lopsoft.countries'))).'','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('hasAbility', ['languages.access'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-sublink','data' => ['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('languages.index')).'','text' => ''.e(mb_strtoupper(__('lopsoft.tables.languages'))).'','class' => 'hover:text-green-300','help' => '']]); ?>
<?php $component->withName('lopsoft.control.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-user','link' => ''.e(route('languages.index')).'','text' => ''.e(mb_strtoupper(__('lopsoft.tables.languages'))).'','class' => 'hover:text-green-300','help' => '']); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>


     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.sidebar-link','data' => ['icon' => 'hover:text-red-500 fa fa-sign-out','text' => 'SALIR','help' => 'SALIR','class' => 'hover:text-red-500','onclick' => 'document.getElementById(\'formlogout\').submit();']]); ?>
<?php $component->withName('lopsoft.control.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'hover:text-red-500 fa fa-sign-out','text' => 'SALIR','help' => 'SALIR','class' => 'hover:text-red-500','onclick' => 'document.getElementById(\'formlogout\').submit();']); ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

</div>
<?php /**PATH /devel/collegium/resources/views/lopsoft/layouts/partials/sidebar.blade.php ENDPATH**/ ?>