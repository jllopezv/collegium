<div class='pt-8 px-4 pb-4 rounded-b-md bg-white'>
<?php /**PATH /devel/collegium/resources/views/livewire/partials/bottomcard.blade.php ENDPATH**/ ?>