<?php $attributes = $attributes->exceptProps([
    'active'    =>  '0',
]); ?>
<?php foreach (array_filter(([
    'active'    =>  '0',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<tr class="border-b border-gray-300 hover:bg-cool-gray-200  <?php echo e($active=='1'?'bg-transparent':'bg-red-100'); ?>">
    <?php echo e($slot); ?>

</tr>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/body-tr.blade.php ENDPATH**/ ?>