<?php $attributes = $attributes->exceptProps([
    'label'         =>  '',
    'color'         =>  'text-gray-500',
    'classlabel'    =>  '',
    'model'         =>  '',
    'positionlabel' =>  'after',    // after, before
]); ?>
<?php foreach (array_filter(([
    'label'         =>  '',
    'color'         =>  'text-gray-500',
    'classlabel'    =>  '',
    'model'         =>  '',
    'positionlabel' =>  'after',    // after, before
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <label class="inline-flex items-center">
        <?php if($positionlabel=='before'): ?> <span class="mr-2 text-sm <?php echo e($classlabel); ?>"><?php echo e($label); ?></span> <?php endif; ?>
        <input type="checkbox" <?php echo e($attributes); ?> wire:model='<?php echo e($model); ?>'
            class="form-checkbox cursor-pointer h-5 w-5 <?php echo e($color); ?>

                hover:shadow-none hover:border-gray-500
                active:shadow-none
                focus:shadow-none focus:border-gray-500">
        <?php if($positionlabel=='after'): ?> <span class="ml-2 text-sm <?php echo e($classlabel); ?>"><?php echo e($label); ?></span> <?php endif; ?>
    </label>
</div>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/control/checkbox.blade.php ENDPATH**/ ?>