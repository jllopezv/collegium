 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.inputform','data' => ['wire:model.lazy' => 'role','id' => 'role','xRef' => 'role','label' => ''.e(transup('role')).'','classcontainer' => 'w-1/2','nextref' => 'level','requiredfield' => true,'help' => ''.e(transup('mandatory_unique')).'','autofocus' => true,'mode' => ''.e($mode).'']]); ?>
<?php $component->withName('lopsoft.control.inputform'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'role','id' => 'role','x-ref' => 'role','label' => ''.e(transup('role')).'','classcontainer' => 'w-1/2','nextref' => 'level','requiredfield' => true,'help' => ''.e(transup('mandatory_unique')).'','autofocus' => true,'mode' => ''.e($mode).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.inputform','data' => ['wire:model.lazy' => 'level','id' => 'level','xRef' => 'level','label' => ''.e(transup('level')).'','classcontainer' => 'w-20','nextref' => 'description','requiredfield' => true,'help' => ''.e(transup('mandatory')).'','mode' => ''.e($mode).'']]); ?>
<?php $component->withName('lopsoft.control.inputform'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'level','id' => 'level','x-ref' => 'level','label' => ''.e(transup('level')).'','classcontainer' => 'w-20','nextref' => 'description','requiredfield' => true,'help' => ''.e(transup('mandatory')).'','mode' => ''.e($mode).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.inputform','data' => ['wire:model.lazy' => 'dashboard','id' => 'dashboard','xRef' => 'dashboard','label' => ''.e(transup('dashboard')).'','classcontainer' => 'w-1/2','nextref' => 'color','mode' => ''.e($mode).'']]); ?>
<?php $component->withName('lopsoft.control.inputform'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'dashboard','id' => 'dashboard','x-ref' => 'dashboard','label' => ''.e(transup('dashboard')).'','classcontainer' => 'w-1/2','nextref' => 'color','mode' => ''.e($mode).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class='w-3/4 sm:w-1/3'>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('controls.drop-down-table-component', [
        'model'         => \App\Models\Aux\Color::class,
        'mode'          =>  $mode,
        'filterraw'     => '',
        'label'         => transup('color'),
        'key'           => 'id',
        'field'         => 'name',
        'defaultvalue'  => $record->color_id??null,
        'eventname'     => 'eventsetcolor',
        'linknew'       => route('colors.create'),
        'uid'           => 'colorcomponent',
        'modelid'       => 'color_id',
        'template'      => 'components.lopsoft.dropdown.colors',
        'cansearch'     => false,
    ])->html();
} elseif ($_instance->childHasBeenRendered('EjBqJP4')) {
    $componentId = $_instance->getRenderedChildComponentId('EjBqJP4');
    $componentTag = $_instance->getRenderedChildComponentTagName('EjBqJP4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EjBqJP4');
} else {
    $response = \Livewire\Livewire::mount('controls.drop-down-table-component', [
        'model'         => \App\Models\Aux\Color::class,
        'mode'          =>  $mode,
        'filterraw'     => '',
        'label'         => transup('color'),
        'key'           => 'id',
        'field'         => 'name',
        'defaultvalue'  => $record->color_id??null,
        'eventname'     => 'eventsetcolor',
        'linknew'       => route('colors.create'),
        'uid'           => 'colorcomponent',
        'modelid'       => 'color_id',
        'template'      => 'components.lopsoft.dropdown.colors',
        'cansearch'     => false,
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('EjBqJP4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH /devel/collegium/resources/views/livewire/tables/auth/roles/form.blade.php ENDPATH**/ ?>