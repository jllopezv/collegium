<?php $attributes = $attributes->exceptProps([
    'table'     =>  '',
    'model'     =>  null,
    'data'      =>  null,
    'title'     =>  '',
    'canadd'    =>  'true',
    'canselect' =>  'true',
    'showlocks' =>  '0',
    'minwidth'  =>  '700px',
    'minheight' =>  '500px',
    'cansearch' => 'true',
    'slave'     => 'false',
]); ?>
<?php foreach (array_filter(([
    'table'     =>  '',
    'model'     =>  null,
    'data'      =>  null,
    'title'     =>  '',
    'canadd'    =>  'true',
    'canselect' =>  'true',
    'showlocks' =>  '0',
    'minwidth'  =>  '700px',
    'minheight' =>  '500px',
    'cansearch' => 'true',
    'slave'     => 'false',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div x-data='{ screen_width: getScreenWidth() }' @resize.window='screen_width=getScreenWidth()'>
    <div
        
        class='<?php echo e(($slave=='true')?'pt-2 rounded-t-lg bg-gray-700':''); ?>' >
    </div>
    <div class='flex flex-wrap items-center justify-between <?php echo e(($slave!='true')?'mb-2':'bg-gray-700 px-2 py-2'); ?> '>
        <div class=''>

            <?php if($canadd!='false'): ?>
                <?php if(Auth::user()->hasAbility($table.".create")): ?>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.link.success','data' => ['link' => ''.e(route($table.'.create')).'','icon' => 'fa fa-plus','text' => 'NUEVO']]); ?>
<?php $component->withName('lopsoft.link.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['link' => ''.e(route($table.'.create')).'','icon' => 'fa fa-plus','text' => 'NUEVO']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php endif; ?>
            <?php endif; ?>
            <?php echo e($tableactions); ?>

        </div>
        <div class='flex items-center justify-center '>
            <?php if($cansearch!='false'): ?>
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.searchbar','data' => ['textcolor' => ''.e($slave=='true'?'text-white':'').'']]); ?>
<?php $component->withName('lopsoft.datatable.searchbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['textcolor' => ''.e($slave=='true'?'text-white':'').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php if (\Illuminate\Support\Facades\Blade::check('isAdmin')): ?>
                    <div class='ml-1'>
                        <?php if(property_exists($model,'hasactive')): ?>
                            <?php if($showlocks!='1'): ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.link.gray','data' => ['wire:click' => 'showLock(true)','icon' => 'fa fa-lock','help' => 'VER TODOS','helpclass' => 'tooltiptext-up-left']]); ?>
<?php $component->withName('lopsoft.link.gray'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'showLock(true)','icon' => 'fa fa-lock','help' => 'VER TODOS','helpclass' => 'tooltiptext-up-left']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php else: ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.link.gray','data' => ['wire:click' => 'showLock(false)','icon' => 'fa fa-unlock','help' => 'VER SOLO ACTIVOS','helpclass' => 'tooltiptext-up-left']]); ?>
<?php $component->withName('lopsoft.link.gray'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'showLock(false)','icon' => 'fa fa-unlock','help' => 'VER SOLO ACTIVOS','helpclass' => 'tooltiptext-up-left']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

    </div>
    <div x-show='!(screen_width>640)'>
        <?php if($slave=='true'): ?>
            <div class='w-full pb-2 bg-gray-700 rounded-b-lg'></div>
        <?php endif; ?>
    </div>
</div>


<div x-data='{ screen_width: getScreenWidth() }' @resize.window='screen_width=getScreenWidth()'>
    <div x-show='screen_width>640' class='w-full shadow'>
        <div class='flex justify-center w-full'>
            <div class='w-full overflow-x-auto bg-white '>
                <div class='overflow-y-hidden'  style='min-height: <?php echo e($minheight); ?>; min-width: <?php echo e($minwidth); ?>'>
                    <table class='w-full table-fixed'>
                        <thead>
                            <?php echo e($header); ?>

                        </thead>
                        <tbody>
                            <?php echo e($body); ?>

                        </tbody>
                    </table>
                    <?php echo e($nodata); ?>

                </div>
            </div>
        </div>
    </div>
    <div x-show='screen_width<=640' class='w-full p-4'>
        <div class='flex justify-center w-full'>
            <div class='w-full overflow-x-auto'>
                <div>
                    <table class='w-full table-fixed'>
                        <?php echo e($headerxs); ?>

                        <?php echo e($bodyxs); ?>

                    </table>
                        <?php echo e($nodata); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo e($links); ?>


<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/mainlayout.blade.php ENDPATH**/ ?>