<?php $__env->startSection('header'); ?>
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th','data' => ['class' => 'w-16','justify' => 'end','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'id']]); ?>
<?php $component->withName('lopsoft.datatable.header-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-16','justify' => 'end','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'id']); ?>ID <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th','data' => ['class' => 'w-60','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'role']]); ?>
<?php $component->withName('lopsoft.datatable.header-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-60','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'role']); ?><?php echo e(transup('role')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th','data' => ['class' => 'w-3/4','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'level']]); ?>
<?php $component->withName('lopsoft.datatable.header-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-3/4','sortable' => true,'sortorder' => ''.e($sortorder).'','columnname' => 'level']); ?><?php echo e(transup('level')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headerxs'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('livewire.layouts.indexlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /devel/collegium/resources/views/livewire/tables/auth/roles/roles-index.blade.php ENDPATH**/ ?>