<?php if($mode=='create'): ?>
    <?php echo $__env->make('livewire.partials.headeraaction', ['headertext' => 'CREAR NUEVO REGISTRO'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($mode=='edit'): ?>
    <?php echo $__env->make('livewire.partials.headeraaction', ['headertext' => 'MODIFICAR REGISTRO'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($mode=='show'): ?>
    <?php echo $__env->make('livewire.partials.headeraaction', ['headertext' => 'VER REGISTRO'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($mode=='index'): ?>
    <?php echo $__env->make('livewire.partials.headeraaction', ['headertext' => $title ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /devel/collegium/resources/views/livewire/partials/states/commonheader.blade.php ENDPATH**/ ?>