<tr class='bg-gray-700 text-green-300'>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/header-tr.blade.php ENDPATH**/ ?>