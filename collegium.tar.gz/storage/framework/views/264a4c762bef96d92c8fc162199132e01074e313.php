<?php $attributes = $attributes->exceptProps([
    'label'         => '',
    'sublabel'      => '',
    'placeholder'   => '',
    'disabled'      => false,
    'labelwidth'    => '',
    'labelclass'    => '',
    'id'            => Str::random(20),
    'showerror'     => true,
    'requiredfield' => false,
    'nextref'       => '',
    'help'          => '',
    'classcontainer' => '',
    'mode'          =>  'create',
]); ?>
<?php foreach (array_filter(([
    'label'         => '',
    'sublabel'      => '',
    'placeholder'   => '',
    'disabled'      => false,
    'labelwidth'    => '',
    'labelclass'    => '',
    'id'            => Str::random(20),
    'showerror'     => true,
    'requiredfield' => false,
    'nextref'       => '',
    'help'          => '',
    'classcontainer' => '',
    'mode'          =>  'create',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>



<div class='py-4'>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.label','data' => ['class' => 'font-bold '.e($labelclass).' '.e($errors->has($id)?'text-red-600 ':'').'','text' => ''.$label.'','labelwidth' => ''.e($labelwidth).'']]); ?>
<?php $component->withName('lopsoft.control.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'font-bold '.e($labelclass).' '.e($errors->has($id)?'text-red-600 ':'').'','text' => ''.$label.'','labelwidth' => ''.e($labelwidth).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php if($sublabel): ?>
            <div class='text-sm text-gray-400'><?php echo e($sublabel); ?></div>
        <?php endif; ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.input','data' => ['id' => ''.e($id).'','name' => ''.e($id).'','disabled' => ''.e($disabled ? "disabled" : "").'','classcontainer' => ''.e($classcontainer).'','attributes' => $attributes->merge([
            'class' => ($errors->has($id)?'border-red-500':'')
        ]),'placeholder' => ''.e($placeholder).'','nextref' => ''.e($nextref).'','requiredfield' => ''.e($requiredfield).'','help' => ''.$help.'','mode' => ''.e($mode).'']]); ?>
<?php $component->withName('lopsoft.control.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => ''.e($id).'','name' => ''.e($id).'','disabled' => ''.e($disabled ? "disabled" : "").'','classcontainer' => ''.e($classcontainer).'','attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes->merge([
            'class' => ($errors->has($id)?'border-red-500':'')
        ])),'placeholder' => ''.e($placeholder).'','nextref' => ''.e($nextref).'','requiredfield' => ''.e($requiredfield).'','help' => ''.$help.'','mode' => ''.e($mode).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <?php if($showerror): ?>
        <?php if( $errors->has($id) ): ?>
            <div>
                <span class='text-red-500'><?php echo e(($errors->get($id))[0]); ?></span>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php echo e($slot); ?>


</div>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/control/inputform.blade.php ENDPATH**/ ?>