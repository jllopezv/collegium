<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.6.0/dist/alpine.js" defer></script>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/lib/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/noty.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lopsoft.js')); ?>"></script>

<?php /**PATH /devel/collegium/resources/views/lopsoft/layouts/partials/scripts.blade.php ENDPATH**/ ?>