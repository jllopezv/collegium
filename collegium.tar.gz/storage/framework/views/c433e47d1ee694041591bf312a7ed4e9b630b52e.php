<div class='border-t border-gray-700 m-2'></div>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/control/profilemenu-separator.blade.php ENDPATH**/ ?>