<?php $attributes = $attributes->exceptProps([ 'text' => null, 'icon' => null, 'link' => null, 'ref' => '', 'help' => '', 'helpclass' => 'tooltiptext-up-center', 'textxs' => false  ]); ?>
<?php foreach (array_filter(([ 'text' => null, 'icon' => null, 'link' => null, 'ref' => '', 'help' => '', 'helpclass' => 'tooltiptext-up-center', 'textxs' => false  ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a
    <?php if($ref): ?>
        x-ref="<?php echo e($ref); ?>"
    <?php endif; ?>
    <?php echo e($attributes->merge([
    'class' => 'inline-flex items-center tooltip
                px-4 py-2 border border-transparent
                rounded-md font-bold text-sm text-white uppercase
                focus:outline-none  focus:shadow-none
                cursor-pointer transition ease-in-out duration-150
                bg-gray-500 hover:bg-gray-600 active:bg-gray-500 focus:border-gray-500'
    ])); ?>


    <?php if($link): ?>
        href='<?php echo e($link); ?>'
    <?php endif; ?>

    >

    <div class='flex items-center justify-center '>
        <?php if($icon): ?>
            <div class="">
                <i class='<?php echo $icon; ?>'></i>
            </div>
        <?php endif; ?>
        <?php if($text): ?>
            <div class="<?php echo e(($slot!='' && $textxs!==false)?'mr-1':'ml-1'); ?>  <?php echo e($textxs===false?'hidden sm:block':'block'); ?>">
                <?php echo $text; ?>

            </div>
        <?php endif; ?>
        <div>
            <?php echo e($slot); ?>

        </div>
        <?php if($help!=""): ?>
            <span class='tooltiptext <?php echo e($helpclass); ?>'>
                <?php echo $help; ?>

            </span>
        <?php endif; ?>
    </div>
</a>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/link/link-base.blade.php ENDPATH**/ ?>