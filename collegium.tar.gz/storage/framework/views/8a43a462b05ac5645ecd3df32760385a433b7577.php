<div class='relative' >

    <?php echo $__env->make('livewire.partials.loading-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div wire:loading.delay.class='opacity-50'>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.mainlayout','data' => ['table' => ''.e($table).'','model' => ''.e($model).'','data' => ''.e($data).'','title' => ''.$title.'','canadd' => ''.e($canadd).'','canselect' => ''.e($canselect).'','showlocks' => ''.e($showlocks).'','minwidth' => ''.e($minwidth??'700px').'','cansearch' => ''.e($cansearch).'','slave' => ''.e($slave).'']]); ?>
<?php $component->withName('lopsoft.datatable.mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['table' => ''.e($table).'','model' => ''.e($model).'','data' => ''.e($data).'','title' => ''.$title.'','canadd' => ''.e($canadd).'','canselect' => ''.e($canselect).'','showlocks' => ''.e($showlocks).'','minwidth' => ''.e($minwidth??'700px').'','cansearch' => ''.e($cansearch).'','slave' => ''.e($slave).'']); ?>
            
                 <?php $__env->slot('tableactions'); ?> 
                    <?php if(count($rowselected)): ?>
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.danger','data' => ['icon' => 'fa fa-trash','wire:click' => 'destroyBatch']]); ?>
<?php $component->withName('lopsoft.button.danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'fa fa-trash','wire:click' => 'destroyBatch']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php if(property_exists($model,'hasactive')): ?>
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.warning','data' => ['wire:click' => 'lockBatch','help' => 'BLOQUEAR REGISTRO','helpclass' => 'tooltiptext-up-right','class' => 'ml-1','icon' => 'fa fa-lock']]); ?>
<?php $component->withName('lopsoft.button.warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'lockBatch','help' => 'BLOQUEAR REGISTRO','helpclass' => 'tooltiptext-up-right','class' => 'ml-1','icon' => 'fa fa-lock']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.success','data' => ['wire:click' => 'unlockBatch','help' => 'DESBLOQUEAR REGISTRO','helpclass' => 'tooltiptext-up-right','class' => 'ml-1','icon' => 'fa fa-unlock']]); ?>
<?php $component->withName('lopsoft.button.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'unlockBatch','help' => 'DESBLOQUEAR REGISTRO','helpclass' => 'tooltiptext-up-right','class' => 'ml-1','icon' => 'fa fa-unlock']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('header'); ?> 
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-tr','data' => []]); ?>
<?php $component->withName('lopsoft.datatable.header-tr'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <?php if($canselect!=='false'): ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th-checkbox','data' => ['class' => 'w-20']]); ?>
<?php $component->withName('lopsoft.datatable.header-th-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-20']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php endif; ?>
                        <?php echo $__env->yieldContent('header'); ?>
                        <?php if($showactions!='false'): ?>
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th-space','data' => ['class' => 'w-3/4']]); ?>
<?php $component->withName('lopsoft.datatable.header-th-space'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-3/4']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.header-th-actions','data' => ['class' => 'w-32','justify' => 'end','actioncandelete' => ''.e($actioncandelete).'','actioncanlock' => ''.e($actioncanlock).'','actioncanedit' => ''.e($actioncanedit).'']]); ?>
<?php $component->withName('lopsoft.datatable.header-th-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-32','justify' => 'end','actioncandelete' => ''.e($actioncandelete).'','actioncanlock' => ''.e($actioncanlock).'','actioncanedit' => ''.e($actioncanedit).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('body'); ?> 
                    <?php if(!is_null($data)): ?>
                        <?php if($data->count()): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.body-tr','data' => ['active' => ''.e($item->active??true).'']]); ?>
<?php $component->withName('lopsoft.datatable.body-tr'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['active' => ''.e($item->active??true).'']); ?>
                                    <?php if($canselect!=='false'): ?>
                                        <?php if($item->allowDelete() || $item->allowLock()): ?>
                                            <?php if($item->canDeleteRecord() || $item->canLockRecord() || $item->canUnlockRecord() || $item->canCustomActionRecord() ): ?>
                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-checkbox','data' => ['id' => 'row'.e($index).'','value' => ''.e($item->id).'']]); ?>
<?php $component->withName('lopsoft.datatable.row-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'row'.e($index).'','value' => ''.e($item->id).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            <?php else: ?>
                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-checkbox','data' => ['id' => 'row'.e($index).'','value' => ''.e($item->id).'','readonly' => true]]); ?>
<?php $component->withName('lopsoft.datatable.row-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'row'.e($index).'','value' => ''.e($item->id).'','readonly' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            <?php endif; ?>
                                        <?php else: ?>
                                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-checkbox','data' => ['id' => 'row'.e($index).'','value' => ''.e($item->id).'','readonly' => true]]); ?>
<?php $component->withName('lopsoft.datatable.row-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'row'.e($index).'','value' => ''.e($item->id).'','readonly' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php echo $__env->make('components.lopsoft.datatable.rowcolumn', ['slot'=> $item->id, 'classrow' => 'text-right'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('livewire.tables.'.$module.".".$table.".indexbody", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php if($showactions!='false'): ?>
                                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-column-space','data' => []]); ?>
<?php $component->withName('lopsoft.datatable.row-column-space'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-actions','data' => ['table' => ''.e($table).'','model' => ''.e($model).'','itemid' => ''.e($item->id).'','active' => ''.e($item->active??null).'','actioncandelete' => ''.e($actioncandelete).'','actioncanlock' => ''.e($actioncanlock).'','actioncanedit' => ''.e($actioncanedit).'']]); ?>
<?php $component->withName('lopsoft.datatable.row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['table' => ''.e($table).'','model' => ''.e($model).'','itemid' => ''.e($item->id).'','active' => ''.e($item->active??null).'','actioncandelete' => ''.e($actioncandelete).'','actioncanlock' => ''.e($actioncanlock).'','actioncanedit' => ''.e($actioncanedit).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    <?php endif; ?>
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('headerxs'); ?> 
                    <?php echo $__env->yieldContent('headerxs'); ?>
                    <?php if($canselect!=='false'): ?>
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.checkbox','data' => ['label' => 'SELECCIONAR PAGINA','model' => 'rowselectpage','color' => 'text-green-400','classlabel' => 'font-bold']]); ?>
<?php $component->withName('lopsoft.control.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'SELECCIONAR PAGINA','model' => 'rowselectpage','color' => 'text-green-400','classlabel' => 'font-bold']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.control.checkbox','data' => ['label' => 'SELECCIONAR TODOS','model' => 'rowselectall','color' => 'text-green-600','classlabel' => 'font-bold']]); ?>
<?php $component->withName('lopsoft.control.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'SELECCIONAR TODOS','model' => 'rowselectall','color' => 'text-green-600','classlabel' => 'font-bold']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('bodyxs'); ?> 
                    <?php if(!is_null($data)): ?>
                        <?php if($data->count()): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class='p-2 m-2 bg-white rounded-lg shadow'>
                                    <div class='flex items-center justify-between'>
                                        <div class=''>
                                            <?php if($canselect!=='false'): ?>
                                                <input
                                                id="row<?php echo e($index); ?>"
                                                value="<?php echo e($item->id); ?>"
                                                type='checkbox'
                                                wire:model='rowselected'
                                                class="w-5 h-5 text-green-400 cursor-pointer form-checkbox hover:shadow-none hover:border-gray-500 active:shadow-none focus:shadow-none focus:border-gray-500"
                                                />
                                            <?php endif; ?>
                                        </div>
                                        <div class=''>
                                            
                                            <span class='bg-blue-500 text-white py-0.5 px-1 text-xs rounded font-bold'>ID <?php echo e($item->id); ?></span>
                                            <?php if(property_exists($model,'hasactive')): ?>
                                                <?php if($item->active): ?>
                                                    <span class='bg-green-400 text-white py-0.5 px-1 text-xs rounded font-bold'>ACTIVO</span>
                                                <?php else: ?>
                                                    <span class='bg-red-500 text-white py-0.5 px-1 text-xs rounded font-bold'>NO ACTIVO</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>

                                    <?php echo $__env->make('livewire.tables.'.$module.".".$table.".indexbodyxs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <div  class='text-right'>
                                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.datatable.row-actions-xs','data' => ['table' => ''.e($table).'','model' => ''.e($model).'','itemid' => ''.e($item->id).'','active' => ''.e($item->active??true).'']]); ?>
<?php $component->withName('lopsoft.datatable.row-actions-xs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['table' => ''.e($table).'','model' => ''.e($model).'','itemid' => ''.e($item->id).'','active' => ''.e($item->active??true).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('nodata'); ?> 
                    <?php if(is_null($data) || !$data->count()): ?>
                        <div class='p-4 font-bold text-gray-500'>NO HAY DATOS PARA MOSTRAR</div>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
            
                 <?php $__env->slot('links'); ?> 
                    <?php if( !is_null($data) ): ?>
                        <?php if( $data->count() ): ?>
                            <div class='w-full p-4'>
                                <div>
                                    <span class='text-sm text-gray-700'>Total registros <?php echo e((!$showlocks && property_exists($model,'hasactive') )?$model::active()->count().' de ':''); ?> <?php echo e($model::all()->count()); ?>.</span>
                                    <?php if(count($rowselected)): ?> <span class='text-sm text-gray-700'>Registros seleccionados: <?php echo e(count($rowselected)); ?></span><?php endif; ?>
                                </div>
                                
                                <?php echo e($data->links()); ?>

                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
            
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div>
<?php /**PATH /devel/collegium/resources/views/livewire/layouts/indexlayout.blade.php ENDPATH**/ ?>