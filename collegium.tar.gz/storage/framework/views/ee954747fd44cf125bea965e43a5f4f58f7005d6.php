<?php $attributes = $attributes->exceptProps([
    'itemid'    =>  '0',
    'table'     =>  '',
    'active'    =>  '0',
    'model'     =>  null,
    'actioncandelete'  =>  'true',
    'actioncanedit'    =>  'true',
    'actioncanlock'    =>  'true',
]); ?>
<?php foreach (array_filter(([
    'itemid'    =>  '0',
    'table'     =>  '',
    'active'    =>  '0',
    'model'     =>  null,
    'actioncandelete'  =>  'true',
    'actioncanedit'    =>  'true',
    'actioncanlock'    =>  'true',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $record=$model::find($itemid);
?>

<?php if(!is_null($record)): ?>
    <div class='pt-2'>
        
        <?php if($actioncanedit==='true'): ?>
            <?php if($record->allowEdit()): ?>
                <?php if($record->canEditRecord()): ?>
                    <div class='tooltip'>
                        <a href='<?php echo e(route($table.'.edit',$itemid)); ?>'><i  class=' fa fa-pencil-alt fa-lg fa-fw text-cool-gray-400 hover:text-cool-gray-600'></i></a>
                        <span class='tooltiptext tooltiptext-up-left'>EDITAR</span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if($actioncandelete==='true'): ?>
            <?php if($record->allowDelete()): ?>
                <?php if($record->canDeleteRecord()): ?>
                    <div class='tooltip'>
                        <i wire:click="delete(<?php echo e($itemid); ?>)" class='text-red-400 cursor-pointer fa fa-trash fa-lg fa-fw hover:text-red-600'></i>
                        <span class='tooltiptext tooltiptext-up-left'>BORRAR</span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
        <?php if($actioncanlock==='true'): ?>
            <?php if(property_exists($model,'hasactive')): ?>
                <?php if($record->allowLock()): ?>
                    <?php if($active!='1'): ?>
                        <?php if($record->canUnlockRecord()): ?>
                            
                            <div class='tooltip'>
                                <i wire:click="unlock(<?php echo e($itemid); ?>)" class='cursor-pointer fa fa-unlock fa-lg fa-fw text-cool-gray-400 hover:text-cool-gray-600'></i>
                                <span class='tooltiptext tooltiptext-up-left'>DESBLOQUEAR</span>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($record->canLockRecord()): ?>
                            
                            <div class='tooltip'>
                                <i wire:click="lock(<?php echo e($itemid); ?>)" class='cursor-pointer fa fa-lock fa-lg fa-fw text-cool-gray-400 hover:text-cool-gray-600'></i>
                                <span class='tooltiptext tooltiptext-up-left'>BLOQUEAR</span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/row-actions-xs.blade.php ENDPATH**/ ?>