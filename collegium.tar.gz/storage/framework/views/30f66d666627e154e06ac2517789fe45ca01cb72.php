<?php echo $__env->make('livewire.layouts.formlayout-begin', ['classcard' => 'max-w-3xl'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('livewire.tables.'.$module.'.'.$table.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('livewire.layouts.formlayout-end', ['flassmessage' => $table.'saved', 'firstref' => 'role' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /devel/collegium/resources/views/livewire/tables/auth/roles/roles-show.blade.php ENDPATH**/ ?>