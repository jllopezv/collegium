<?php if(isset($saveandexit) && $saveandexit): ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.gray','data' => ['xRef' => 'btnUpdate','@click' => '$refs.group.focus()','icon' => 'fa fa-check','text' => 'ACTUALIZAR','wire:click' => 'update(true)','class' => 'ml-1']]); ?>
<?php $component->withName('lopsoft.button.gray'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-ref' => 'btnUpdate','@click' => '$refs.group.focus()','icon' => 'fa fa-check','text' => 'ACTUALIZAR','wire:click' => 'update(true)','class' => 'ml-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php else: ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.gray','data' => ['xRef' => 'btnUpdate','@click' => '$refs.group.focus()','icon' => 'fa fa-check','text' => 'ACTUALIZAR','wire:click' => 'update','class' => 'ml-1']]); ?>
<?php $component->withName('lopsoft.button.gray'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-ref' => 'btnUpdate','@click' => '$refs.group.focus()','icon' => 'fa fa-check','text' => 'ACTUALIZAR','wire:click' => 'update','class' => 'ml-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lopsoft.button.danger','data' => ['xRef' => 'btnCancel','@click' => '$refs.group.focus()','icon' => 'fa fa-times','text' => 'CANCELAR','wire:click' => 'goBack','class' => 'ml-1']]); ?>
<?php $component->withName('lopsoft.button.danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-ref' => 'btnCancel','@click' => '$refs.group.focus()','icon' => 'fa fa-times','text' => 'CANCELAR','wire:click' => 'goBack','class' => 'ml-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /devel/collegium/resources/views/livewire/partials/editbuttons.blade.php ENDPATH**/ ?>