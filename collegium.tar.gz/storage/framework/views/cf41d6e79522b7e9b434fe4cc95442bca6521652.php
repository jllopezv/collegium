<div x-data='{}' class='relative w-full'>

    <?php echo $__env->make('livewire.partials.loading-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div wire:loading.delay.class='opacity-50' >

        <div class='w-full <?php echo e($classcard); ?> mx-auto'>

            <?php echo $__env->make('livewire.partials.topcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('livewire.partials.createmultiples', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('livewire.partials.bottomcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /devel/collegium/resources/views/livewire/layouts/formlayout-begin.blade.php ENDPATH**/ ?>