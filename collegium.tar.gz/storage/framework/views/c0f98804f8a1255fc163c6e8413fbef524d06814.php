<?php $attributes = $attributes->exceptProps([
    'width'         => '',
    'columnname'    => 'columnname',
    'order'         => '',
    'sortable'      => false,
    'justify'       => 'start'
]); ?>
<?php foreach (array_filter(([
    'width'         => '',
    'columnname'    => 'columnname',
    'order'         => '',
    'sortable'      => false,
    'justify'       => 'start'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<th

    <?php echo e($attributes->merge([
        'class' => '',
        'width' =>  $width,
    ])); ?>

    style='max-width: 100%; width: auto'>
    <?php echo e($slot); ?>

</th>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/datatable/header-th-space.blade.php ENDPATH**/ ?>