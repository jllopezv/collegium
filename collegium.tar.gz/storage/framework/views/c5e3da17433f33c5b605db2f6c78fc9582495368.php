<?php $attributes = $attributes->exceptProps(['icon','link','text', 'menuid', 'help' => '', 'look' => '' ,'classmenu' => '']); ?>
<?php foreach (array_filter((['icon','link','text', 'menuid', 'help' => '', 'look' => '' ,'classmenu' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class=''>
    <div
        x-on:click.prevent="menuEvent('<?php echo e($menuid); ?>')"
        class='p-2 mx-2 text-gray-500 transition-all duration-300 rounded-md cursor-pointer hover:bg-gray-700 <?php echo e($classmenu!=''?$classmenu:'hover:text-gray-400'); ?> ' >

        <div class='flex justify-between'>
            <div class='flex items-center'>
                <div class="pr-1"
                    x-on:click.prevent="iconEvent('<?php echo e($menuid); ?>')">
                        <i class='<?php echo e($icon); ?> fa-lg fa-fw'></i>
                </div>
                <div
                    <?php echo e($attributes); ?>

                    :class="' font-bold transition-all duration-300 '+(opensidebar?'visible opacity-100  text-left':'opacity-0 invisible')">
                    <?php echo $text; ?>

                </div>
            </div>
            <div
                <?php echo e($attributes); ?>

                :class="' font-bold transition-all duration-300 '+(opensidebar?'visible opacity-100  text-left':'invisible opacity-0')">
                <i id='iconsidebarmenu_<?php echo e($menuid); ?>' class='fa fa-angle-down'></i>
            </div>
        </div>

    </div>
    <div  id='sidebarmenu_<?php echo e($menuid); ?>' :class="' '+(opensidebar?'opacity-100 block text-left':'opacity-0 hidden')" style='display: none;'>
        <?php echo $slot; ?>

    </div>
</div>
<?php /**PATH /devel/collegium/resources/views/components/lopsoft/control/sidebar-menu.blade.php ENDPATH**/ ?>