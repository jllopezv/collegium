<div class='bg-white shadow-md rounded-b-md'>

    <?php echo $__env->make('livewire.partials.recordcard-header', [
        'title'     => $title,
        'subtitle'  => $subtitle,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <hr>

    <?php echo $__env->make('livewire.partials.recordinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /devel/collegium/resources/views/livewire/partials/topcard.blade.php ENDPATH**/ ?>