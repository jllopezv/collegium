<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link href="<?php echo e(asset('css/fontawesome/all.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/lib/toastr.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/lib/noty.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('js/lib/freakflags/freakflags.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/lopsoft.css')); ?>" rel="stylesheet">

<style>
    [x-cloak] { display: none; }
</style>


<?php /**PATH /devel/collegium/resources/views/lopsoft/layouts/partials/styles.blade.php ENDPATH**/ ?>